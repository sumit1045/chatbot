# `stdout` push adapter

This is an adapter which logs push notifications to `STDOUT` where they can be redirected to file or processed by some other service.
This adapter is primarily intended for debugging and logging.
