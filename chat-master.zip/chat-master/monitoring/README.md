# Monitoring Support

This directory contains code related to monitoring Tinode server. Supported monitoring services are
* [Prometheus](https://prometheus.io/)
* [InfluxDB](https://www.influxdata.com/)

See [exporter/README](./exporter/README.md) for more details.
